﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;

namespace ConsoleApplication1 {
	class Program {

		static void Print_Error() { // функция вывода ошибки
			Console.WriteLine("Ошибка! Для справки введите -help");
			Console.WriteLine("Нажмите любую клавишу для выхода!");
			Console.ReadKey();
		}
		static void d(string str) { //функция вывода строки (для отладки)
			Console.WriteLine(str);
		}
		static void Print_Help() { //функция вывода справки
			Console.WriteLine("Параметры для ввода:");
			Console.WriteLine("1/2             Первый/Второй тип преобразования;");
			Console.WriteLine("input           Путь к файлу с функциями;");
			Console.WriteLine("output          Путь к выходному файлу;");
			Console.WriteLine("Нажмите любую клавишу для выхода!");
			Console.ReadKey();
		}


		// функция проверки входных параметров, проверяет на тип преобразования, на существование файлов и количество параметров
		static bool is_param_validate(int param_count, string param1 = "", string param2 = "", string param3 = "") {
			if (param_count == 0) {
				return false;
			}

			if (param_count == 1) if (param1 != "-help") return false;

			if (param_count == 2 || param_count > 3) {
				return false;
			}

			if (param_count == 3) {
				bool error = false;

				if (param1 != "1" && param1 != "2") error = true;
				if (File.Exists(param2) == false) error = true;
				if (File.Exists(param3) == false) error = true;

				return !error;
			}

			return true;
		}

		static void Main(string[] args) {
			// Если количество аргументов равно нулю - ошибка
			if (args.Count() == 0) Print_Error();

			// Если количество аргументов равно единице, но аргумент не равен "-help" - ошибка
			if (args.Count() == 1) {
				if (is_param_validate(1, args[0]) == false) {
					Print_Error();
					return;
				} else Print_Help();
			}

			// Если количество аргументов равно двум - ошибка
			// Если количество аргументов больше - ошибка
			if (args.Count() == 2) {
				Print_Error();
				return;
			}


			//если количество аргументов = трём, то сделать проверку этих параметров функцией is_param_validate
			if (args.Count() == 3) {
				Converter cnvrter = new Converter();

				if (is_param_validate(3, args[0], args[1], args[2]) == true) {
					if (args[0] == "1") {
						cnvrter.converter1(args[1], args[2]);
						Console.WriteLine("Конвертация 1 прошла успешно!");
					}

					if (args[0] == "2") {
						cnvrter.converter2(args[1], args[2]);
						Console.WriteLine("Конвертация 2 прошла успешно!");
					}
				} else Print_Error();
			}
		}
	}
}